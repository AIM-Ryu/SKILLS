#!/usr/bin/env python3
"""Build an .ics calendar file from a simple JSON event list.

Python standard library only. No pip install, no API key, no authentication.
Timezone is fixed to Asia/Tokyo (Japan has had no DST since 1951).

This script is OPTIONAL. The aim-schedule skill also works by writing the
.ics text directly with the Write tool. Use this script when there are many
events and hand-writing them would risk a typo.

Usage:
    python3 make_ics.py <events.json> <output.ics>

events.json format (a list of objects):
[
  {"key": "tanaka-material", "title": "【素材】受け取り期限（田中さん）", "date": "2026-08-10"},
  {"key": "tanaka-first-draft", "title": "【初稿】提出（田中さん）",
   "date": "2026-08-18", "start": "18:00", "end": "18:30",
   "description": "Frame.io にアップして共有リンクを送る"}
]

Rules:
- "key" becomes the UID as-is ("tanaka-material" -> "tanaka-material@aim-schedule"),
  which is the same value reference_ics.md tells you to write by hand. Use
  "<client>-<purpose>", lowercase ASCII / digits / hyphens only, and NEVER put
  a date in it: a key containing the date creates a duplicate every time the
  schedule moves. If "key" is omitted the title is hashed instead, which is
  fine only for one-off files that will never be redrawn.
- "date" only            -> all-day event
- "date" + "start"       -> timed event (end defaults to start + 30 minutes)
- "description" is optional. Use \\n in the JSON string for line breaks.

Safety:
- Refuses to overwrite an existing output file. Rename to _v2 instead.
- Refuses to run if two events resolve to the same UID.
"""

import json
import os
import re
import sys
import uuid
from datetime import datetime, timedelta, timezone

TZID = "Asia/Tokyo"

# Fixed VTIMEZONE block. Japan has no daylight saving time, so a single
# STANDARD component with +0900 is enough for Google / Apple / Outlook.
VTIMEZONE = [
    "BEGIN:VTIMEZONE",
    f"TZID:{TZID}",
    "BEGIN:STANDARD",
    "DTSTART:19700101T000000",
    "TZOFFSETFROM:+0900",
    "TZOFFSETTO:+0900",
    "TZNAME:JST",
    "END:STANDARD",
    "END:VTIMEZONE",
]

DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
TIME_RE = re.compile(r"^\d{1,2}:\d{2}$")


def fail(message):
    """Stop with a message the skill can show to the user as-is."""
    print(f"エラー: {message}", file=sys.stderr)
    sys.exit(1)


def escape_text(value):
    """Escape a text value for an iCalendar property (RFC 5545 3.3.11)."""
    return (
        value.replace("\\", "\\\\")
        .replace(";", "\\;")
        .replace(",", "\\,")
        .replace("\r\n", "\\n")
        .replace("\n", "\\n")
    )


def fold(line):
    """Fold a content line to 75 octets, never splitting a multi-byte char."""
    raw = line.encode("utf-8")
    if len(raw) <= 75:
        return [line]
    out = []
    limit = 75
    buf = b""
    for char in line:
        encoded = char.encode("utf-8")
        if len(buf) + len(encoded) > limit:
            out.append(buf.decode("utf-8"))
            buf = b""
            limit = 74  # continuation lines start with one leading space
        buf += encoded
    if buf:
        out.append(buf.decode("utf-8"))
    return [out[0]] + [" " + part for part in out[1:]]


def parse_date(value, label):
    if not isinstance(value, str) or not DATE_RE.match(value):
        fail(f"{label}の日付が YYYY-MM-DD 形式ではありません: {value!r}")
    try:
        return datetime.strptime(value, "%Y-%m-%d")
    except ValueError:
        fail(f"{label}に存在しない日付が入っています: {value!r}")


def parse_time(value, label):
    if not isinstance(value, str) or not TIME_RE.match(value):
        fail(f"{label}の時刻が HH:MM 形式ではありません: {value!r}")
    hour, minute = value.split(":")
    hour, minute = int(hour), int(minute)
    if hour > 23 or minute > 59:
        fail(f"{label}に存在しない時刻が入っています: {value!r}")
    return hour, minute


def build_event(item, index, stamp):
    label = f"{index + 1}件目のイベント"
    if not isinstance(item, dict):
        fail(f"{label}がオブジェクトではありません")

    title = item.get("title")
    if not title or not isinstance(title, str):
        fail(f"{label}に title がありません")

    day = parse_date(item.get("date"), label)

    # Stable UID. "key" becomes the UID as-is, so a file written by hand
    # (reference_ics.md) and a file built by this script produce the SAME UID
    # for the same event. If they differed, switching routes between v1 and v2
    # would duplicate every entry in the calendar.
    # The key must not contain a date: when the schedule is redrawn the event
    # keeps its UID, so the calendar updates it instead of adding a duplicate.
    key = item.get("key")
    if key is not None and not isinstance(key, str):
        fail(f"{label}の key が文字列ではありません")
    if key:
        if not re.match(r"^[a-z0-9][a-z0-9-]*$", key):
            fail(
                f"{label}の key は半角英小文字・数字・ハイフンだけにしてください: {key!r}\n"
                "（クライアント名はローマ字の略称にします。例: tanaka-material）"
            )
        if re.search(r"\d{8}|\d{4}-\d{2}-\d{2}", key):
            fail(
                f"{label}の key に日付が入っています: {key!r}\n"
                "日付を入れると、日程が変わったときに予定が重複します。"
                "用途だけの名前にしてください（例: tanaka-first-draft）。"
            )
        uid = f"{key}@aim-schedule"
    else:
        # key を省略した場合のみ。使い捨てのファイル向けで、引き直しには向きません。
        uid = f"{uuid.uuid5(uuid.NAMESPACE_URL, title)}@aim-schedule"

    sequence = item.get("sequence", 1)
    if not isinstance(sequence, int) or isinstance(sequence, bool) or sequence < 0:
        fail(f"{label}の sequence は0以上の整数にしてください: {sequence!r}")

    lines = ["BEGIN:VEVENT"]
    lines.append(f"UID:{uid}")
    lines.append(f"DTSTAMP:{stamp}")
    # A higher SEQUENCE tells the calendar this is a newer version of the
    # event. Raise it when re-issuing a changed schedule (_v2 -> 2).
    lines.append(f"SEQUENCE:{sequence}")

    if item.get("start"):
        hour, minute = parse_time(item["start"], label)
        start = day.replace(hour=hour, minute=minute)
        if item.get("end"):
            end_hour, end_minute = parse_time(item["end"], label)
            end = day.replace(hour=end_hour, minute=end_minute)
            if end <= start:
                fail(f"{label}の終了時刻が開始時刻より前です: {title}")
        else:
            end = start + timedelta(minutes=30)
        fmt = "%Y%m%dT%H%M%S"
        lines.append(f"DTSTART;TZID={TZID}:{start.strftime(fmt)}")
        lines.append(f"DTEND;TZID={TZID}:{end.strftime(fmt)}")
    else:
        # All-day events use an exclusive end date, so add one day.
        lines.append(f"DTSTART;VALUE=DATE:{day.strftime('%Y%m%d')}")
        lines.append(f"DTEND;VALUE=DATE:{(day + timedelta(days=1)).strftime('%Y%m%d')}")

    lines.append(f"SUMMARY:{escape_text(title)}")
    if item.get("description"):
        lines.append(f"DESCRIPTION:{escape_text(str(item['description']))}")
    lines.append("END:VEVENT")
    return uid, lines


def main():
    if len(sys.argv) != 3:
        fail("使い方: python3 make_ics.py <events.json> <output.ics>")

    src, dest = sys.argv[1], sys.argv[2]

    if not os.path.exists(src):
        fail(f"入力ファイルが見つかりません: {src}")
    if os.path.exists(dest):
        fail(
            f"出力先がすでに存在します: {dest}\n"
            "既存ファイルは上書きしません。_v2 など別の名前を指定してください。"
        )

    try:
        with open(src, encoding="utf-8") as handle:
            events = json.load(handle)
    except json.JSONDecodeError as error:
        fail(f"入力ファイルの書式が壊れています: {error}")

    if not isinstance(events, list) or not events:
        fail("入力ファイルは、1件以上のイベントが入ったリストにしてください")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//AIM//aim-schedule//JA",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
    ]
    lines += VTIMEZONE
    seen = {}
    for index, item in enumerate(events):
        uid, event_lines = build_event(item, index, stamp)
        if uid in seen:
            fail(
                f"{index + 1}件目と{seen[uid]}件目のイベントが同じ予定として扱われます。\n"
                "key（または title）が重複しています。key は案件ごと・用途ごとに"
                "違う値にしてください（例: tanaka-material / tanaka-first-draft）。"
            )
        seen[uid] = index + 1
        lines += event_lines
    lines.append("END:VCALENDAR")

    folded = []
    for line in lines:
        folded += fold(line)

    # RFC 5545 requires CRLF line endings.
    with open(dest, "w", encoding="utf-8", newline="") as handle:
        handle.write("\r\n".join(folded) + "\r\n")

    print(f"作成しました: {dest}（イベント {len(events)} 件）")


if __name__ == "__main__":
    main()
